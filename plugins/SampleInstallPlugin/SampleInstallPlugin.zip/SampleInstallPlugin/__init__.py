from plugins.templatemodule import TemplateModule

def SampleInstallPlugin():
    """
    SampleInstallPlugin is a plugin that demonstrates installation
    of a plugin
    """
    def __init__(self):
        super().__init__()
        print("External Plugin Loaded Successfully!")
        pass