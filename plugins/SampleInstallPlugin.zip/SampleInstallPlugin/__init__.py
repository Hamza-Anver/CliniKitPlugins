from plugins.templatemodule import TemplateModule

class SampleInstallPlugin(TemplateModule):
    """
    SampleInstallPlugin is a plugin that demonstrates installation
    of a plugin
    """
    pass